
import {useState} from 'react'
import Dashboard from './Dashboard'

import {Text, TextInput , View , TouchableOpacity , StyleSheet , ImageBackground} from 'react-native'
export default function Signin({navigation}){
  const [userName , setUserName]=useState("");
   const [password , setPassword]=useState("");
  const [email , setEmail]=useState("");
  const [phoneNumber , setPhoneNumber] =useState("");
 async function buttonHandler(){
   const newData={
     email:userName,
     password:password,
     returnSecureToken:'true'
   }
   const response=await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signUp?key=[AIzaSyD8oYu1Gjxkc77uMLrxfvZo7oBCO3IeFO8]' ,{
     method:'POST',
     headers : {
     Accept:'application/json',
     'Content-type':'application/json'
     },
   body:JSON.stringify(newData)

   });
   const data=await response.json();
   
   if(data.idToken){
     alert("user registered successfully");
     navigation.navigate("Dashboard");
   }
   else{
     alert("user does not registered");
   }
  

    
  }
  return(
    <View style={styles.total}>
    <ImageBackground style={styles.backgroundimage} source={{
     uri: 'https://miro.medium.com/v2/resize:fit:1200/1*XUrSasLtkB0VoXcLEMfJKg.jpeg'   }}>
     <View style={styles.inner}>
   
<Text style={styles.full}>Signin Detail</Text>
<TextInput style={styles.input} onChangeText={(text => setUserName(text))} placeholder="Enter username"></TextInput>
<TextInput style={styles.input} onChangeText={(text => setPassword(text))} placeholder="Enter Password"></TextInput>
<TextInput style={styles.input} onChangeText={(text => setEmail(text))} placeholder="abc@gmail.com"></TextInput>

 <TextInput style={styles.input} onChangeText={text=>setPhoneNumber(text)} placeholder="Enter your Phone Number"></TextInput>

<TouchableOpacity style={styles.button} onPress={buttonHandler}><Text>Signin</Text></TouchableOpacity>
</View>
    </ImageBackground>
</View>
  );
}
const styles=StyleSheet.create({
  total:{
    flex:1,
    
    
  },
  backgroundimage:{
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode:'cover',
    
  },
  inner:{
    paddingTop:10,
    borderRadius:20,
    paddingBottom:100,
    position:'absolute',
   
    marginBottom:10,
    top:'25%',
    left:'10%',
    backgroundColor: '#2C3E50',
    height:300,
    padding:1,
    width:250,
    bottom:'10%',
    justifyContent:'center',
    alignItems:'center',
    alignContent:'center',
    
    
  },
  full:{
    backgroundColor:'skyblue',
    padding:20,
    
    fontSize:10,
    margin:5,
    marginTop:100,
    flexShrink:1  ,
    borderRadius:10,
  },
  input:{
    backgroundColor:'skyblue',
    textAlign:'center',
    justifyContent :'center',
     margin:5,
    padding:10,
    borderRadius:10,
  },
  button:{
    position:'relative',
    backgroundColor:'skyblue',
    textAlign:'center',
    justifyContent:'center',
    marginTop:5,
    marginLeft:100,
    marginRight:130,
    padding:3,
    borderRadius:10,
    width:60,
  }
 
});