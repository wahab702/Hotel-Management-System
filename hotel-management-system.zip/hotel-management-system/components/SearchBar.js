
import {View , TextInput , StyleSheet} from 'react-native'
import {useState} from 'react'


export default function SearchBar(){
const [search , setSearch]=useState("");
return(
  <View style={styles.full}>
  <TextInput style={styles.search} onChangeText={(text=>setSearch(text))} placeholder="Search Location" ></TextInput>

  </View>



);
}
const styles=StyleSheet.create({
  full:{
    padding:10,
    backgroundColor:'white'
    
  },
  search:{
     height: 40,
    borderColor: 'gray',
    borderWidth: 1,
  }
});