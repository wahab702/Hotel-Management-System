
import {useState} from 'react'
import Dashboard from './Dashboard'
import Signin from './Signin'

import {Text, TextInput , View , TouchableOpacity , StyleSheet , ImageBackground} from 'react-native'
export default function Login({navigation}){
  const [userName , setUserName]=useState("");
  const [password , setPassword]=useState("");
  async function buttonHandler(){
    const newData={
      email:userName,
      password:password,
      returnSecureToken:true
    }
    const response=await fetch('https://identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=[AIzaSyD8oYu1Gjxkc77uMLrxfvZo7oBCO3IeFO8]',{
      method : 'POST',
      headers : {
        Accept:'application/json',
        'Content-Type': 'application/json'
      },
      body:JSON.stringify(newData)
    });
    const data=await response.json();
    if(data.registered==true){
      alert("login successfully");
      navigation.navigate("Dashboard");
    }
    else{
      alert(" Credential does not match")
    }

    
  }
function buttonHandler1(){

    navigation.navigate(Signin);
  }
  return(
    <View style={styles.total}>
    <ImageBackground style={styles.backgroundimage} source={{
     uri: 'https://miro.medium.com/v2/resize:fit:1200/1*XUrSasLtkB0VoXcLEMfJKg.jpeg'   }}>
     <View style={styles.inner}>
   
<Text style={styles.full}>LoginDetail</Text>
<TextInput style={styles.input} onChangeText={(text => setUserName(text))} placeholder="Enter username"></TextInput>
<TextInput style={styles.input} onChangeText={(text => setPassword(text))} placeholder="Enter Password"></TextInput>
<TouchableOpacity style={styles.button} onPress={buttonHandler}><Text>Login</Text></TouchableOpacity>
<TouchableOpacity style={styles.button1} onPress={buttonHandler1}><Text>Signin</Text></TouchableOpacity>
</View>
    </ImageBackground>
</View>
  );
}
const styles=StyleSheet.create({
  total:{
    flex:1,
    
    
  },
  backgroundimage:{
    flex: 1,
    width: '100%',
    height: '100%',
    resizeMode:'cover',
    
  },
  inner:{
    paddingTop:10,
    borderRadius:20,
    paddingBottom:100,
    position:'absolute',
   
    marginBottom:10,
    top:'25%',
    left:'10%',
    backgroundColor: '#2C3E50',
    height:300,
    padding:1,
    width:250,
    bottom:'10%',
    justifyContent:'center',
    alignItems:'center',
    alignContent:'center',
    
    
  },
  full:{
    backgroundColor:'skyblue',
    padding:20,
    
    fontSize:20,
    margin:5,
    marginTop:100,
    flexShrink:1  ,
    borderRadius:10,
  },
  input:{
    backgroundColor:'skyblue',
    textAlign:'center',
    justifyContent :'center',
     margin:5,
    padding:10,
    borderRadius:10,
  },
  button:{
    position:'relative',
    backgroundColor:'skyblue',
    textAlign:'center',
    justifyContent:'center',
    marginTop:5,
    marginLeft:100,
    marginRight:130,
    padding:10,
    borderRadius:10,
    width:60,
  },
  button1:{
    position:'relative',
    backgroundColor:'skyblue',
    marginTop:0,
    marginBottom:10,
    textAlign:'center',
    justifyContent:'center',
    marginLeft:260,
    marginRight:130,
    padding:10,
    borderRadius:10,
    width:60,
  }
});