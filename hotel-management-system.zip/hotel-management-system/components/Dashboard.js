

import { View, StyleSheet } from 'react-native';
import { createDrawerNavigator } from '@react-navigation/drawer';

import Booking from './Booking';
import SearchBar from './SearchBar'; 

const Drawer = createDrawerNavigator();

export default function Dashboard({navigation}) {
 

  return (
    <View style={styles.full}>
     
      <SearchBar />
      
     
        <Drawer.Navigator >
          
          <Drawer.Screen name="Booking" component={Booking}/>
          <Drawer.Screen name="SearchBar" component={SearchBar}/>
        
          
          
        </Drawer.Navigator>
      
    </View>
  );
}

const styles = StyleSheet.create({
  full: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
