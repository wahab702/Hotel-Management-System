
import {View  , TextInput , StyleSheet , TouchableOpacity , Text } from 'react-native'
import {Picker} from '@react-native-picker/picker'
import {useState} from 'react'
export default function Booking({navigation}){
  const [name , setName] =useState("");
  const [phoneNumber , setPhoneNumber] =useState("");
  const [date , setDate] =useState("");
  const [hotal , setHotal] = useState("");

  const handleDateChange= (text) => {
    if(text.length===2 || text.length===5){
      if(text.length>date.length){
        text+="/";
      }
      else{
        text=text.slice(0,-1);
      }
    }
    setDate(text);
  }
 async function buttonHandler(){
   const newData={
     name:name,
     phoneNumber:phoneNumber,
     date:date,
     hotal:hotal
   }
   const response=await fetch('https://wahab-84809-default-rtdb.firebaseio.com/Wahab.json' ,{
     method:'POST',
     headers : {
       Accept : 'application/json',
       'Content-type':'application/json'
     },
     body: JSON.stringify(newData)
   });
   const data=await response.json();
    if(data.registered==true){
      alert("data enter successfully");
      navigation.navigate("Booking");
    }
    else{
      alert(" Credential does not match")
    }

    

 }
  return(
    <View>
    <Text>Add Booking</Text>
    <TextInput onChangeText={text=>setName(text)} placeholder="Enter your name"></TextInput>
    <TextInput onChangeText={text=>setPhoneNumber(text)} placeholder="Enter your Phone Number"></TextInput>
     <TextInput onChangeText={handleDateChange} placeholder="DD/MM/YYYY" keyboardType="numeric" maxLength="10" value={date}></TextInput>
   <View>
    <Text>Hotel Information</Text>
    <Picker onValueChange={textItems=>setHotal(textItems)} placeholder="Select a hotal">
    <Picker.Item label="Hotal A " value="hotalA" />
    <Picker.Item label="Hotal B " value="hotalB" />
    <Picker.Item label="Hotal C " value="hotalC" />
    </Picker>
    
    </View>
    <TouchableOpacity style={styles.button} onPress={buttonHandler}  ><Text>Add Booking</Text></TouchableOpacity>
     </View>



  );
}