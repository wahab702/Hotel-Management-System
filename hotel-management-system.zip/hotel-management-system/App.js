
import Login from './components/Login'
import Dashboard from './components/Dashboard'
import SearchBar from './components/SearchBar'
import Booking from './components/Booking'
import Signin from './components/Signin'
import {NavigationContainer} from '@react-navigation/native'
import {createNativeStackNavigator} from '@react-navigation/native-stack'

const Stack=createNativeStackNavigator();
export default function App(){
return(
    <NavigationContainer>
    <Stack.Navigator initialRouteName="Login">
    <Stack.Screen name="Login" component={Login}/>
    <Stack.Screen name="Dashboard" component={Dashboard}  />
    <Stack.Screen name="SearchBar" component={SearchBar}  />
    <Stack.Screen name="Booking" component={Booking}  />
    <Stack.Screen name="Signin" component={Signin}  />
    
    
    </Stack.Navigator>
    </NavigationContainer>


);
}